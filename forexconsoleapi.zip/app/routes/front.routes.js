module.exports = myapp => {
  const front = require("../logic/front.logic.js");

  var router = require("express").Router();

  // Retrieve all Tutorials
  router.get("/t", front.console);

  /*
  // Retrieve all published Tutorials
  router.get("/published", tutorials.findAllPublished);

  // Retrieve a single Tutorial with id
  router.get("/:id", tutorials.findOne);

  // Update a Tutorial with id
  router.put("/:id", tutorials.update);

  // Delete a Tutorial with id
  router.delete("/:id", tutorials.delete);

  // Create a new Tutorial
  router.delete("/", tutorials.deleteAll);
*/
  myapp.use('/api/front', router);
};