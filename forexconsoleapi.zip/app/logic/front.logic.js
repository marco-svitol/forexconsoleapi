
const db = require("../database");

exports.console = (req, res) => {
  const title = req.query.title;
  let strQuery = 'SELECT * FROM language_dictionary'
  db.query(strQuery)
    .then(data => {
      res.send(data);
    })
    .catch(err => {
      res.status(500).send({
        message: err.message || "Some error occured while retreiving tutorials."
      });
    });
  };
