const express = require("express");
const app = express();
const bodyParser = require("body-parser");
app.use(bodyParser.json()); // parse requests of content-type - application/json
app.use(bodyParser.urlencoded({ extended: true })); // parse requests of content-type - application/x-www-form-urlencoded
var uuid = require('uuid');
var httpContext = require('express-http-context');
app.use(httpContext.middleware);
app.use(function(req, res, next) { // Run the context for each request. Assign a unique identifier to each request
    httpContext.set('reqId', uuid.v1());
    next();
});

const cors = require("cors");
var corsOptions = {
  origin: "http://localhost:8081"
};
app.use(cors(corsOptions));

const dotenv = require('dotenv');
dotenv.config();

var logger=require('./app/logger'); 

function srvconsoledir(request, start=1, err = 0){ //internal: log service call info to console
  let splitted = request.path.split('/')
  let srvname = splitted[1]
  let params = ""
  if (err==0){
    if (start){
      if (Object.keys(request.body).length != 0){
        params = JSON.stringify(request.body)
        if (srvname == 'login'){params = 'user: ' + request.body.user}
      }else{
        params = JSON.stringify(request.query)
      }
      logger.info(`${srvname} ${request.path} service request from ${request.connection.remoteAddress} : ${params}`)
      //perfy.start(rTracer.id())
    }
    else{
      //let perfSecs = perfy.end(rTracer.id())['time']
      //let perfMsg = `${perfSecs} secs`
      //if ((config_data.log.thresholdProcessTimeWarning < perfSecs) && (perfSecs < config_data.log.thresholdProcessTimeAlert)) {perfMsg = `${perfMsg} LatencyWarning` }
      //else if (perfSecs > config_data.log.thresholdProcessTimeAlert) {perfMsg = `${perfMsg} LatencyAlert` }
      logger.info(`${srvname} service completed for ${request.connection.remoteAddress}`)}}// in ${perfMsg}`)}}
  else{
    logger.error(`${srvname} service requested from ${request.connection.remoteAddress} raised this error: ${JSON.stringify(err)}`)
    //perfy.end(rTracer.id())
    }
}

const db = require("./app/database");

// simple route
app.get("/", (req, res) => {
  res.json({ message: "Welcome to MondialChangeAPI" });
});

app.use((req,res,next) => {
  srvconsoledir(req);
  next();
})

require("./app/routes/pos.routes")(app);
require("./app/routes/front.routes")(app);

// set port, listen for requests
app.listen(process.env.SERVER_PORT, () => {
  logger.info(`Server is running on port ${process.env.SERVER_PORT}.`);
});